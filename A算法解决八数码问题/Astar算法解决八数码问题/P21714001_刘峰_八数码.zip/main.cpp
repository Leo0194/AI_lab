#include <iostream>
#include"function.h"
using namespace std;

int main()
{
	while (true) {
		Solve();
	}
	
	return 0;

}


